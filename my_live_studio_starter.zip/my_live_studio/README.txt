MY LIVE STUDIO — FREE STARTER

WHAT THIS IS
A mobile-friendly static website dashboard for planning YouTube Live streams.
It is not yet connected to YouTube and does not broadcast audio/video by itself.

OPEN LOCALLY
Open index.html in a browser.

PUBLISH FREE WITH GITHUB PAGES
1. Create/sign in to a GitHub account.
2. Create a new PUBLIC repository, e.g. my-live-studio.
3. Upload index.html to the repository's root.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose main and /(root), then Save.
7. Wait for GitHub Pages to publish; use the URL it shows.

NEXT FOR REAL AUTOMATION
- Create a Google Cloud project and enable YouTube Data API v3.
- Set up OAuth consent and authorization securely.
- Build a backend for creating/scheduling broadcasts and binding streams.
- Configure an encoder/streaming engine that can continuously send authorized audio/video.
- Add schedule, error recovery, logs, and secure credential handling.
Do not put OAuth client secrets or stream keys into this public HTML file.
Use only audio/video you own or are licensed to broadcast.
